 <?php
$this->load->view('template/page_head');
$this->load->view('template/header');
$this->load->view('template/sidebar_left');
?>
<!-- main content start -->
  <section id="main-content">
      <section class="wrapper">
        <!--User Registration-->
		<div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        Users List
                        <span class="tools pull-right">
                            <a href="javascript:;" class="fa fa-chevron-down"></a>
                            <a href="javascript:;" class="fa fa-cog"></a>
                            <a href="javascript:;" class="fa fa-times"></a>
                         </span>
                    </header>
                    <div class="panel-body">
                        <table class="table  table-hover general-table">
                            <thead>
                            <tr>
                                <th>NPWP</th>
                                <th>No. ID/KTP</th>
                                <th>Pemilik</th>
                                <th>Username</th>
                                <th>Alamat</th>
                                <th>No Telp</th>
                                <th>No Mobile</th>
                                <th>Email</th>
                                <th>Nama Warung</th>
                                <th>Alamat Warung</th>
                                <!-- <th>Order Detail</th> -->
                                <!-- <th>Status</th> -->
                                <!-- <th>Detail</th> -->
                            </tr>
                            </thead>
                            <!-- isi tabel, ubah ke php untuk loop -->
                            <tbody>
                            <?php foreach ($dataUser as $d) {?>
                            <tr>
                                <td><?php echo $d->npwp; ?></td>
                                <td><?php echo $d->idKtp ?></td>
                                <td><?php echo $d->pemilik ?></td>
                                <td><?php echo $d->userName ?></td>
                                <td><?php echo $d->alamat ?></td>
                                <td><?php echo $d->noTel ?></td>
                                <td><?php echo $d->noMobile ?></td>
                                <td><?php echo $d->email ?></td>
                                <td><?php echo $d->namaWarung ?></td>
                                <td><?php echo $d->alamatWarung ?></td>
                            </tr>

                            <?php }?>
                            <!-- <tr>
                                <td><a href="#">1000938769838467</a></td>
                                <td>Ardian</td>
                                <td>Mujur Terus</td>
                                <td><a href="#">click for detail</a></td>
                                <td><span class="label label-danger label-mini">Canceled</span></td>
                                <td>Out of stock</td>
                            </tr> -->
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
      </section>
  </section>
<!-- main content end -->
 <?php
$this->load->view('template/page_end2');
?>