 <?php
$this->load->view('template/page_head');
$this->load->view('template/header');
$this->load->view('template/sidebar_left');
?>
<!-- main content start -->
  <section id="main-content">
      <section class="wrapper">
        <!--User Registration-->
		<div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        New User Registration
                        <span class="tools pull-right">
                            <a href="javascript:;" class="fa fa-chevron-down"></a>
                            <a href="javascript:;" class="fa fa-cog"></a>
                            <a href="javascript:;" class="fa fa-times"></a>
                         </span>
                    </header>
                    <div class="panel-body">
                        <form action="<?php echo base_url() . 'user_registration/daftar'; ?>" id="wizard" method="POST">
                            <h2>First Step</h2>
                            <!-- Identitas user -->
                            <section>
                            <div class="form-horizontal">
                                		<div class="form-group">
                                            <label class="col-lg-2 control-label">No. ID/KTP</label>
                                            <div class="col-lg-8">
                                                <input name="i_idktp" type="text" class="form-control" placeholder="No. ID/KTP" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">NPWP</label>
                                            <div class="col-lg-8">
                                                <input name="i_npwp" type="text" class="form-control" placeholder="NPWP" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">Nama Lengkap</label>
                                            <div class="col-lg-8">
                                                <input name="i_namaLengkap" type="text" class="form-control" placeholder="Nama Lengkap" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">User Name</label>
                                            <div class="col-lg-8">
                                                <input name="i_userName" type="text" class="form-control" placeholder="Username" required>
                                            </div>
                                        </div>
                                        </div>
                            </section>

                            <h2>Second Step</h2>
                            <!-- cara menghubungi user -->
                            <section>
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">No Telepon</label>
                                        <div class="col-lg-8">
                                            <input name="i_noTelp" type="text" class="form-control" placeholder="No Telepon"  required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">No Mobile</label>
                                        <div class="col-lg-8">
                                            <input name="i_noMobile" type="text" class="form-control" placeholder="No Mobile"  required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                            <label class="col-lg-2 control-label">Email</label>
                                            <div class="col-lg-8">
                                                <input name="i_email"type="text" class="form-control" placeholder="Email" required>
                                            </div>
                                        </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">Alamat</label>
                                        <div class="col-lg-8">
                                            <textarea name="i_alamat" class="form-control" cols="60" rows="5" required></textarea>
                                        </div>
                                    </div>
                                </div>
                            </section>

                            <h2>Third Step</h2>
                            <!-- keterangan warung -->
                            <section>
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">Nama Warung</label>
                                        <div class="col-lg-8">
                                            <input name="i_namaWarung" type="text" class="form-control" placeholder="Nama Warung"  required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">Alamat Warung</label>
                                        <div class="col-lg-8">
                                            <textarea name="i_alamatWarung"class="form-control" cols="60" rows="5" required></textarea>
                                        </div>
                                    </div>
                                </div>
                            </section>

 <!-- <h2>Fourth Step</h2> -->
                            <!-- keterangan Agen -->
                           <!--  <section>
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">ID Agent  Toko</label>
                                        <div class="col-lg-8">
                                            <input name="i_namaToko" type="text" class="form-control" placeholder="Nama Toko"  required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">Alamat Toko</label>
                                        <div class="col-lg-8">
                                            <textarea name="i_alamatToko"class="form-control" cols="60" rows="5" required></textarea>
                                        </div>
                                    </div>
                                </div>
                            </section>
 -->

                            <h2>Final Step</h2>
                            <section>
                                <div class="form-horizontal">
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">Password</label>
                                        <div class="col-lg-8">
                                            <input name="i_password"type="password" class="form-control" placeholder="" required>
                                        </div>
                                    </div>
                                    <!-- <div class="form-group">
                                        <label class="col-lg-2 control-label">Konfirmasi Password</label>
                                        <div class="col-lg-8">
                                            <input type="password" class="form-control" placeholder="">
                                        </div>
                                    </div> -->
                                </div>
                                <p>Congratulations This is the Final Step</p>
                            </section>

                        </form>
                    </div>
                </section>
            </div>
        </div>
        <!-- page end-->

      <!--   <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading">
                        Register More User Using Excel
                        <span class="tools pull-right">
                            <a href="javascript:;" class="fa fa-chevron-down"></a>
                            <a href="javascript:;" class="fa fa-cog"></a>
                            <a href="javascript:;" class="fa fa-times"></a>
                         </span>
                    </header>
                    <div class="panel-body">
                        <form id="upload" method="post" action="upload.php" enctype="multipart/form-data">
                        	You can drop excel file or browse it to upload file
                            <div id="drop">
                                Drop Here

                                <a>Browse</a>
                                <input type="file" name="upl" multiple />
                            </div>

                            <ul>
                            </ul>

                        </form>
                    </div>
                </section>
            </div>
        </div> -->
      </section>
  </section>
<!-- main content end -->
<?php
$this->load->view('template/page_end2');
?>


<script>
    $(function ()
    {

        $("#wizard").steps({
            headerTag: "h2",
            bodyTag: "section",
            transitionEffect: "slideLeft",
            onFinished: function (event, currentIndex)
            {
                var form = $(this);

                // Submit form input
                form.submit();
            }

        });

        $("#wizard-vertical").steps({
            headerTag: "h2",
            bodyTag: "section",
            transitionEffect: "slideLeft",
            stepsOrientation: "vertical"
        });
    });


</script>